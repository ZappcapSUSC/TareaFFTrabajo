﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class ModeloTarea
    {
        //Modelo de tabla Tareas
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
